# PRoot Builder

Automated GitHub Actions workflow that builds PRoot for Android across multiple architectures using the Android NDK.

## Available Architectures

- `aarch64` (ARM64)
- `arm` (ARMv7a)
- `x86_64`
- `x86`

## Features

- Automated builds
- Static linking with `talloc` library (no runtime dependencies)
- Optimized binaries with `-O3` and section garbage collection
- Release packaging with checksums (SHA256 & MD5)
- Changelog generation from latest commits

## Download

Download the latest release from the [Releases page](https://github.com/ahmed-alnassif/proot/releases).

Each release includes:
- `proot-<arch>.zip` - Binary package per architecture
- `checksums.txt` - SHA256 checksums
- `checksums-md5.txt` - MD5 checksums

## Build Requirements

- Android NDK r29
- talloc 2.4.3 (statically linked)

## Package Contents

Each architecture package contains:

```text
proot-<arch>.zip
├── proot          # Main PRoot executable
└── loader/        # PRoot loader components
```

## License

This repository builds PRoot from the [official Termux repository](https://github.com/termux/proot). This repo licensed under GPLv3.

## Related Links

- [PRoot Official Repository](https://github.com/termux/proot)
- [Android NDK Documentation](https://developer.android.com/ndk)
- [talloc Library](https://www.samba.org/ftp/talloc/)

---

**Note:** This is an automated build repository. For issues with the PRoot binary itself, please report to the [upstream project](https://github.com/termux/proot).
